<?php
require_once 'db.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user'])) {
    $course_name = $_POST['course_name'] ?? '';
    $date_start = trim($_POST['date_start'] ?? '');
    $payment_type = $_POST['payment_type'] ?? '';
    $user_id = $_SESSION['user']['id'];

    if (!empty($course_name) && !empty($date_start) && !empty($payment_type)) {
        $stmt = $pdo->prepare("INSERT INTO orders (user_id, course_name, date_start, payment_type) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$user_id, $course_name, $date_start, $payment_type])) {
            $message = "<div class='alert alert-success'>Заявка успешно отправлена!</div>";
        } else {
            $message = "<div class='alert alert-danger'>Ошибка при отправке заявки.</div>";
        }
    }
}

$my_orders = [];
if (isset($_SESSION['user']) && $_SESSION['user']['role'] !== 'admin') {
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC");
    $stmt->execute([$_SESSION['user']['id']]);
    $my_orders = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Главная — Корочки.есть</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <a href="index.php" class="logo">Корочки.есть</a>
            <nav>
                <?php if(isset($_SESSION['user'])): ?>
                    <span>Привет, <b><?=htmlspecialchars($_SESSION['user']['fio'])?></b></span>
                    <?php if($_SESSION['user']['role'] === 'admin'): ?>
                        <a href="admin.php">Админка</a>
                    <?php endif; ?>
                    <a href="logout.php" class="btn-logout">Выйти</a>
                <?php else: ?>
                    <a href="login.php">Вход</a>
                    <a href="register.php">Регистрация</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    <main class="container">
        <section class="welcome">
            <h2>Онлайн-платформа курсов «Корочки.есть»</h2>
            <p>Освойте востребованные IT-профессии быстро и легко.</p>
        </section>

        <?php if(isset($_SESSION['user']) && $_SESSION['user']['role'] !== 'admin'): ?>
            <div class="grid">
                <div class="card">
                    <h3>Оставить заявку на курс</h3>
                    <?=$message?>
                    <form action="index.php" method="POST">
                        <div class="form-group">
                            <label>Выберите курс:</label>
                            <select name="course_name" required>
                                <option value="Основы алгоритмизации и программирования">Основы алгоритмизации и программирования</option>
                                <option value="Основы веб-дизайна">Основы веб-дизайна</option>
                                <option value="Основы проектирования баз данных">Основы проектирования баз данных</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Дата начала (ДД.ММ.ГГГГ):</label>
                            <input type="text" name="date_start" required placeholder="15.09.2026">
                        </div>
                        <div class="form-group">
                            <label>Способ оплаты:</label>
                            <select name="payment_type" required>
                                <option value="Наличные">Наличные</option>
                                <option value="Перевод">Перевод</option>
                            </select>
                        </div>
                        <button type="submit" class="btn">Отправить заявку</button>
                    </form>
                </div>

                <div class="card">
                    <h3>Мои заявки</h3>
                    <?php if(empty($my_orders)): ?>
                        <p>Вы еще не подали ни одной заявки.</p>
                    <?php else: ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Курс</th>
                                    <th>Дата</th>
                                    <th>Статус</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($my_orders as $order): ?>
                                <tr>
                                    <td><?=htmlspecialchars($order['course_name'])?></td>
                                    <td><?=htmlspecialchars($order['date_start'])?></td>
                                    <td><span class="status-badge"><?=htmlspecialchars($order['status'])?></span></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="alert alert-info" style="text-align: center;">
                Чтобы подать заявку на обучение и просмотреть статус, пожалуйста, <a href="login.php">авторизуйтесь</a>.
            </div>
        <?php endif; ?>
    </main>
</body>
</html>