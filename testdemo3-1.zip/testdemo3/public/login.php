<?php
require_once 'db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($login === 'Admin' && $password === 'KorokNET') {
        $_SESSION['user'] = [
            'id' => 0,
            'login' => 'Admin',
            'fio' => 'Администратор',
            'role' => 'admin'
        ];
        header('Location: admin.php');
        exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM users WHERE login = ?");
    $stmt->execute([$login]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'login' => $user['login'],
            'fio' => $user['fio'],
            'role' => $user['role']
        ];
        
        if ($user['role'] === 'admin') {
            header('Location: admin.php');
        } else {
            header('Location: index.php');
        }
        exit;
    } else {
        $error = "Неверный логин или пароль.";
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход — Корочки.есть</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <a href="index.php" class="logo">Корочки.есть</a>
            <nav>
                <a href="index.php">Главная</a>
                <a href="register.php">Регистрация</a>
            </nav>
        </div>
    </header>

    <main class="container">
        <div class="form-card">
            <h2>Авторизация</h2>
            <?php if($error): ?> <div class="alert alert-danger"><?=$error?></div> <?php endif; ?>

            <form action="login.php" method="POST">
                <div class="form-group">
                    <label>Логин:</label>
                    <input type="text" name="login" required>
                </div>
                <div class="form-group">
                    <label>Пароль:</label>
                    <input type="password" name="password" required>
                </div>
                <button type="submit" class="btn">Войти</button>
            </form>
            <p class="form-footer">Еще не зарегистрированы? <a href="register.php">Регистрация</a></p>
        </div>
    </main>
</body>
</html>