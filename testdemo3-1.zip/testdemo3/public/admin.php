<?php
require_once 'db.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'], $_POST['new_status'])) {
    $order_id = intval($_POST['order_id']);
    $new_status = $_POST['new_status'];

    if (in_array($new_status, ['Идет обучение', 'Обучение завершено'])) {
        $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $order_id]);
    }
}

$stmt = $pdo->query("SELECT orders.*, users.fio, users.phone FROM orders JOIN users ON orders.user_id = users.id ORDER BY orders.id DESC");
$all_orders = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель администратора — Корочки.есть</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <a href="index.php" class="logo">Панель Администратора</a>
            <nav>
                <a href="index.php">На главную</a>
                <a href="logout.php" class="btn-logout">Выйти</a>
            </nav>
        </div>
    </header>

    <main class="container">
        <h2>Все заявки пользователей</h2>
        
        <?php if(empty($all_orders)): ?>
            <p>Заявок в системе пока нет.</p>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>ФИО студента</th>
                        <th>Телефон</th>
                        <th>Курс</th>
                        <th>Дата начала</th>
                        <th>Оплата</th>
                        <th>Текущий статус</th>
                        <th>Действие</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($all_orders as $order): ?>
                    <tr>
                        <td><?=$order['id']?></td>
                        <td><?=htmlspecialchars($order['fio'])?></td>
                        <td><?=htmlspecialchars($order['phone'])?></td>
                        <td><?=htmlspecialchars($order['course_name'])?></td>
                        <td><?=htmlspecialchars($order['date_start'])?></td>
                        <td><?=htmlspecialchars($order['payment_type'])?></td>
                        <td>
                            <span class="status-badge"><?=htmlspecialchars($order['status'])?></span>
                        </td>
                        <td>
                            <?php if($order['status'] === 'Новая'): ?>
                                <form action="admin.php" method="POST" style="display:inline-block;">
                                    <input type="hidden" name="order_id" value="<?=$order['id']?>">
                                    <input type="hidden" name="new_status" value="Идет обучение">
                                    <button type="submit" class="btn btn-sm">Начать обучение</button>
                                </form>
                            <?php elseif($order['status'] === 'Идет обучение'): ?>
                                <form action="admin.php" method="POST" style="display:inline-block;">
                                    <input type="hidden" name="order_id" value="<?=$order['id']?>">
                                    <input type="hidden" name="new_status" value="Обучение завершено">
                                    <button type="submit" class="btn btn-sm btn-success">Завершить</button>
                                </form>
                            <?php else: ?>
                                <span style="color: gray; font-size: 13px;">Закрыта</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </main>
</body>
</html>