<?php
require_once 'db.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fio = trim($_POST['fio'] ?? '');
    $login = trim($_POST['login'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';

    // Валидация по обновленным требованиям
    if (!preg_match('/^[а-яА-ЯёЁ\s]+$/u', $fio)) {
        $error = "ФИО должно содержать только кириллицу и пробелы.";
    } elseif (!preg_match('/^[a-zA-Z0-9]{6,}$/', $login)) {
        $error = "Логин должен быть латиницей (и цифры), не менее 6 символов.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Некорректный формат Email.";
    } elseif (!preg_match('/^8\d{10}$/', $phone)) { // Измененное регулярное выражение
        $error = "Телефон должен быть в формате 8xxxxxxxxxx (11 цифр без пробелов и знаков).";
    } elseif (strlen($password) < 8) {
        $error = "Пароль должен быть не менее 8 символов.";
    } else {
        // Проверка на уникальность логина
        $stmt = $pdo->prepare("SELECT id FROM users WHERE login = ?");
        $stmt->execute([$login]);
        if ($stmt->fetch()) {
            $error = "Этот логин уже занят.";
        } else {
            // Хешируем пароль для безопасности
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $role = ($login === 'Admin') ? 'admin' : 'user';

            $stmt = $pdo->prepare("INSERT INTO users (fio, login, email, phone, password, role) VALUES (?, ?, ?, ?, ?, ?)");
            if ($stmt->execute([$fio, $login, $email, $phone, $hashed_password, $role])) {
                $success = "Регистрация успешна! Теперь вы можете авторизоваться.";
            } else {
                $error = "Произошла ошибка при регистрации.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация — Корочки.есть</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <a href="index.php" class="logo">Корочки.есть</a>
            <nav>
                <a href="index.php">Главная</a>
                <a href="login.php">Вход</a>
            </nav>
        </div>
    </header>

    <main class="container">
        <div class="form-card">
            <h2>Регистрация</h2>
            <?php if($error): ?> <div class="alert alert-danger"><?=$error?></div> <?php endif; ?>
            <?php if($success): ?> <div class="alert alert-success"><?=$success?></div> <?php endif; ?>

            <form action="register.php" method="POST">
                <div class="form-group">
                    <label>ФИО (только кириллица):</label>
                    <input type="text" name="fio" required placeholder="Иванов Иван Иванович">
                </div>
                <div class="form-group">
                    <label>Логин (латиница, от 6 симв.):</label>
                    <input type="text" name="login" required placeholder="user123">
                </div>
                <div class="form-group">
                    <label>Email:</label>
                    <input type="email" name="email" required placeholder="example@mail.ru">
                </div>
                <div class="form-group">
                    <label>Телефон (в формате 8xxxxxxxxxx):</label>
                    <input type="text" name="phone" required placeholder="89991234567">
                </div>
                <div class="form-group">
                    <label>Пароль (от 8 симв.):</label>
                    <input type="password" name="password" required>
                </div>
                <button type="submit" class="btn">Зарегистрироваться</button>
            </form>
            <p class="form-footer">Уже зарегистрированы? <a href="login.php">Вход</a></p>
        </div>
    </main>
</body>
</html>