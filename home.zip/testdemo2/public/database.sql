CREATE DATABASE shopdemo
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE shopdemo;

CREATE TABLE users(
    id INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(50) UNIQUE,
    password VARCHAR(255),
    fio VARCHAR(255),
    email VARCHAR(100),
    role VARCHAR(20) DEFAULT 'user'
);

CREATE TABLE products(
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    description TEXT,
    price DECIMAL(10,2)
);

CREATE TABLE orders(
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    status VARCHAR(50) DEFAULT 'Новый',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY(user_id)
    REFERENCES users(id)
);

CREATE TABLE order_items(
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    product_id INT,
    quantity INT DEFAULT 1,

    FOREIGN KEY(order_id)
    REFERENCES orders(id),

    FOREIGN KEY(product_id)
    REFERENCES products(id)
);

INSERT INTO users
(login,password,fio,email,role)
VALUES
(
'Admin',
'Admin123',
'Администратор',
'admin@mail.ru',
'admin'
);

INSERT INTO products(name,description,price)
VALUES
('Ноутбук','Игровой ноутбук',50000),
('Мышь','Беспроводная мышь',1500),
('Клавиатура','Механическая клавиатура',3500),
('Монитор','24 дюйма IPS',12000);