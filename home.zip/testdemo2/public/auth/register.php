<?php

include "../config/db.php";

if(isset($_POST['register'])){

    $login=$_POST['login'];
    $password=$_POST['password'];
    $fio=$_POST['fio'];
    $email=$_POST['email'];

    mysqli_query(
        $conn,
        "INSERT INTO users
        (login,password,fio,email)
        VALUES
        ('$login','$password','$fio','$email')"
    );

    echo "Пользователь зарегистрирован";
}

?>

<link rel="stylesheet" href="../css/style.css">

<div class="container">

<h2>Регистрация</h2>

<form method="POST">

<input
type="text"
name="login"
placeholder="Логин"
required>

<input
type="password"
name="password"
placeholder="Пароль"
required>

<input
type="text"
name="fio"
placeholder="ФИО"
required>

<input
type="email"
name="email"
placeholder="Email"
required>

<button name="register">
Зарегистрироваться
</button>

</form>

<a href="login.php">
Вход
</a>

</div>