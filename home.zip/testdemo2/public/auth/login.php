<?php

include "../config/db.php";

if(isset($_POST['login_btn'])){

    $login=$_POST['login'];
    $password=$_POST['password'];

    $query=mysqli_query(
        $conn,
        "SELECT * FROM users
        WHERE login='$login'
        AND password='$password'"
    );

    if(mysqli_num_rows($query)>0){

        $user=mysqli_fetch_assoc($query);

        $_SESSION['user_id']=$user['id'];
        $_SESSION['role']=$user['role'];

        if($user['role']=="admin"){

            header("Location: ../admin/admin.php");

        }else{

            header("Location: ../user/catalog.php");

        }

        exit();

    }else{

        echo "Неверный логин или пароль";

    }
}
?>

<link rel="stylesheet" href="../css/style.css">

<div class="container">

<h2>Авторизация</h2>

<form method="POST">

<input
type="text"
name="login"
placeholder="Логин"
required>

<input
type="password"
name="password"
placeholder="Пароль"
required>

<button name="login_btn">
Войти
</button>

</form>

<a href="register.php">
Регистрация
</a>

</div>