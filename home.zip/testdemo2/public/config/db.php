<?php

session_start();

$conn = mysqli_connect(
    "MySQL-8.4",
    "root",
    "",
    "shopdemo"
);

if(!$conn){
    die("Ошибка подключения");
}
?>