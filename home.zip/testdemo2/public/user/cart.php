<?php

include "../config/db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: ../auth/login.php");
}

?>

<link rel="stylesheet" href="../css/style.css">

<div class="container">

<h2>Корзина</h2>

<a href="catalog.php">
Каталог
</a>

<hr>

<?php

if(empty($_SESSION['cart'])){

    echo "Корзина пуста";

}else{

    foreach($_SESSION['cart'] as $product_id){

        $product=mysqli_fetch_assoc(
            mysqli_query(
                $conn,
                "SELECT * FROM products
                WHERE id='$product_id'"
            )
        );

        echo "<p>";

        echo $product['name'];

        echo " - ";

        echo $product['price'];

        echo " ₽";

        echo "</p>";
    }
}

?>

<form method="POST">

<button name="create_order">
Оформить заказ
</button>

</form>

<?php

if(isset($_POST['create_order'])){

    mysqli_query(
        $conn,
        "INSERT INTO orders(user_id)
        VALUES('".$_SESSION['user_id']."')"
    );

    $order_id=mysqli_insert_id($conn);

    foreach($_SESSION['cart'] as $product_id){

        mysqli_query(
            $conn,
            "INSERT INTO order_items
            (order_id,product_id,quantity)
            VALUES
            ('$order_id','$product_id',1)"
        );
    }

    unset($_SESSION['cart']);

    echo "Заказ успешно оформлен";
}

?>

</div>