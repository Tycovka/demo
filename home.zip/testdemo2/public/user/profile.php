<?php

include "../config/db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: ../auth/login.php");
}

$user_id=$_SESSION['user_id'];

$orders=mysqli_query(
    $conn,
    "SELECT * FROM orders
    WHERE user_id='$user_id'
    ORDER BY id DESC"
);

?>

<link rel="stylesheet" href="../css/style.css">

<div class="container">

<h2>Личный кабинет</h2>

<a href="catalog.php">Каталог</a>
<a href="cart.php">Корзина</a>
<a href="../auth/logout.php">Выход</a>

<hr>

<h3>Мои заказы</h3>

<table>

<tr>
<th>Номер заказа</th>
<th>Товары</th>
<th>Дата</th>
<th>Статус</th>
</tr>

<?php while($order=mysqli_fetch_assoc($orders)){ ?>

<tr>

<td>
<?= $order['id'] ?>
</td>

<td>

<?php

$products=mysqli_query(
    $conn,
    "SELECT products.name
    FROM order_items
    JOIN products
        ON products.id = order_items.product_id
    WHERE order_items.order_id='".$order['id']."'"
);

while($product=mysqli_fetch_assoc($products)){

    echo $product['name']."<br>";

}

?>

</td>

<td>
<?= $order['created_at'] ?>
</td>

<td>
<?= $order['status'] ?>
</td>

</tr>

<?php } ?>

</table>

</div>