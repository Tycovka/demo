<?php

include "../config/db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: ../auth/login.php");
}

if(isset($_GET['add'])){

    $id=$_GET['add'];

    $_SESSION['cart'][]=$id;

    echo "Товар добавлен в корзину";
}

$result=mysqli_query(
    $conn,
    "SELECT * FROM products"
);

?>

<link rel="stylesheet" href="../css/style.css">

<div class="container">

<h2>Каталог товаров</h2>

<a href="cart.php">
Корзина
</a>

<a href="profile.php">
Личный кабинет
</a>

<a href="../auth/logout.php">
Выход
</a>

<hr>

<table>

<tr>
<th>ID</th>
<th>Название</th>
<th>Описание</th>
<th>Цена</th>
<th></th>
</tr>

<?php while($product=mysqli_fetch_assoc($result)){ ?>

<tr>

<td>
<?= $product['id'] ?>
</td>

<td>
<?= $product['name'] ?>
</td>

<td>
<?= $product['description'] ?>
</td>

<td>
<?= $product['price'] ?> ₽
</td>

<td>

<a href="?add=<?= $product['id'] ?>">
Добавить в корзину
</a>

</td>

</tr>

<?php } ?>

</table>

</div>