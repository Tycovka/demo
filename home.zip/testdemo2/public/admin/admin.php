<?php

include "../config/db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: ../auth/login.php");
}

if($_SESSION['role']!="admin"){
    die("Доступ запрещен");
}

if(isset($_POST['save_status'])){

    $id=$_POST['order_id'];

    $status=$_POST['status'];

    mysqli_query(
        $conn,
        "UPDATE orders
        SET status='$status'
        WHERE id='$id'"
    );
}

$orders=mysqli_query(
    $conn,
    "SELECT
        orders.*,
        users.fio
    FROM orders
    JOIN users
    ON orders.user_id=users.id
    ORDER BY orders.id DESC"
);

?>

<link rel="stylesheet" href="../css/style.css">

<div class="container">

<h2>Панель администратора</h2>

<a href="../auth/logout.php">
Выход
</a>

<hr>

<table>

<tr>
<th>ID</th>
<th>Покупатель</th>
<th>Дата</th>
<th>Статус</th>
<th>Действие</th>
</tr>

<?php while($order=mysqli_fetch_assoc($orders)){ ?>

<tr>

<form method="POST">

<td>

<?= $order['id'] ?>

<input
type="hidden"
name="order_id"
value="<?= $order['id'] ?>">

</td>

<td>
<?= $order['fio'] ?>
</td>

<td>
<?= $order['created_at'] ?>
</td>

<td>

<select name="status">

<option
<?= $order['status']=='Новый' ? 'selected' : '' ?>>
Новый
</option>

<option
<?= $order['status']=='Подтвержден' ? 'selected' : '' ?>>
Подтвержден
</option>

<option
<?= $order['status']=='Отменен' ? 'selected' : '' ?>>
Отменен
</option>

</select>

</td>

<td>

<button name="save_status">
Сохранить
</button>

</td>

</form>

</tr>

<?php } ?>

</table>

</div>