<?php
session_start();
$conn=mysqli_connect("MySQL-8.4","root","","korochki");
if(!$conn){die("DB error");}
?>
