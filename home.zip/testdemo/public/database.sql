CREATE DATABASE IF NOT EXISTS korochki;
USE korochki;

CREATE TABLE users(
id INT AUTO_INCREMENT PRIMARY KEY,
login VARCHAR(50) UNIQUE,
password VARCHAR(255),
fio VARCHAR(255),
phone VARCHAR(50),
email VARCHAR(100),
role VARCHAR(20) DEFAULT 'user'
);

CREATE TABLE requests(
id INT AUTO_INCREMENT PRIMARY KEY,
user_id INT,
course VARCHAR(255),
start_date DATE,
payment_method VARCHAR(255),
status VARCHAR(100) DEFAULT 'Новая'
);

INSERT INTO users(login,password,fio,phone,email,role)
VALUES('Admin','KorokNET','Администратор','89999999999','admin@mail.ru','admin');
