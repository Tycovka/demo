<?php
include '../config/db.php';
if(isset($_POST['login_btn'])){
$login=$_POST['login']; $password=$_POST['password'];
$q=mysqli_query($conn,"SELECT * FROM users WHERE login='$login' AND password='$password'");
if(mysqli_num_rows($q)){
$user=mysqli_fetch_assoc($q);
$_SESSION['user_id']=$user['id'];
$_SESSION['role']=$user['role'];
if($user['role']=='admin') header('Location: ../admin/admin.php');
else header('Location: ../user/profile.php');
exit;
}
echo 'Неверный логин или пароль';
}
?>
<link rel="stylesheet" href="../css/style.css">
<div class="container"><form method="post">
<h2>Вход</h2>
<input name="login" placeholder="Логин">
<input name="password" placeholder="Пароль">
<button name="login_btn">Войти</button>
<a href="register.php">Регистрация</a>
</form></div>