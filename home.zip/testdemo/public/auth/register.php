<?php
include '../config/db.php';
if(isset($_POST['reg'])){
$login=$_POST['login']; $password=$_POST['password'];
$fio=$_POST['fio']; $phone=$_POST['phone']; $email=$_POST['email'];
mysqli_query($conn,"INSERT INTO users(login,password,fio,phone,email) VALUES('$login','$password','$fio','$phone','$email')");
echo "Регистрация успешна";
}
?>
<link rel="stylesheet" href="../css/style.css">
<div class="container">
<form method="post">
<h2>Регистрация</h2>
<input name="login" placeholder="Логин" required>
<input name="password" placeholder="Пароль" required>
<input name="fio" placeholder="ФИО" required>
<input name="phone" placeholder="Телефон" required>
<input name="email" placeholder="Email" required>
<button name="reg">Создать пользователя</button>
<a href="login.php">Вход</a>
</form></div>