<?php
include '../config/db.php';
if(isset($_POST['send'])){
$uid=$_SESSION['user_id'];
$c=$_POST['course']; $d=$_POST['start_date']; $p=$_POST['payment'];
mysqli_query($conn,"INSERT INTO requests(user_id,course,start_date,payment_method) VALUES('$uid','$c','$d','$p')");
}
?>
<link rel="stylesheet" href="../css/style.css">
<div class="container"><form method="post">
<h2>Заявка</h2>
<select name="course">
<option>Основы алгоритмизации и программирования</option>
<option>Основы веб-дизайна</option>
<option>Основы проектирования баз данных</option>
</select>
<input type="date" name="start_date">
<select name="payment">
<option>Наличными</option>
<option>Перевод по номеру телефона</option>
</select>
<button name="send">Отправить</button>
</form></div>