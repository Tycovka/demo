<?php
include '../config/db.php';
$uid=$_SESSION['user_id'];
$r=mysqli_query($conn,"SELECT * FROM requests WHERE user_id='$uid'");
?>
<link rel="stylesheet" href="../css/style.css">
<div class="container">
<a href="create_request.php">Создать заявку</a>
<a href="../auth/logout.php">Выход</a>
<table><tr><th>Курс</th><th>Дата</th><th>Статус</th></tr>
<?php while($row=mysqli_fetch_assoc($r)){ ?>
<tr><td><?=$row['course']?></td><td><?=$row['start_date']?></td><td><?=$row['status']?></td></tr>
<?php } ?>
</table></div>