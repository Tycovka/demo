<?php
include '../config/db.php';
if(isset($_POST['save'])){
mysqli_query($conn,"UPDATE requests SET status='".$_POST['status']."' WHERE id='".$_POST['id']."'");
}
$r=mysqli_query($conn,"SELECT requests.*,users.fio FROM requests JOIN users ON users.id=requests.user_id");
?>
<link rel="stylesheet" href="../css/style.css">
<div class="container"><h2>Админка</h2>
<table>
<tr><th>ФИО</th><th>Курс</th><th>Статус</th><th></th></tr>
<?php while($row=mysqli_fetch_assoc($r)){ ?>
<tr>
<form method="post">
<td><?=$row['fio']?></td>
<td><?=$row['course']?></td>
<td>
<input type="hidden" name="id" value="<?=$row['id']?>">
<select name="status">
<option>Новая</option>
<option>Идет обучение</option>
<option>Обучение завершено</option>
</select>
</td>
<td><button name="save">Сохранить</button></td>
</form>
</tr>
<?php } ?>
</table></div>